/* Calculator widget */
const REASONS = [
  {value: '', label: 'Select a reason…'},
  {value: 'redundancy', label: 'Redundancy'},
  {value: 'dismissal', label: 'Dismissal'},
  {value: 'resignation', label: 'Resignation'},
  {value: 'mutual', label: 'Mutual agreement'},
  {value: 'other', label: 'Other'},
];

function Calculator({ onCalculate }) {
  const [form, setForm] = React.useState({
    salary: '',
    years: '',
    age: '',
    offer: '',
    reason: '',
    discrimination: 'no',
  });
  const [errors, setErrors] = React.useState({});

  const update = (k, v) => {
    setForm(f => ({...f, [k]: v}));
    if (errors[k]) setErrors(e => ({...e, [k]: undefined}));
  };

  const validate = () => {
    const e = {};
    if (!form.salary || +form.salary < 1000) e.salary = 'Enter your annual salary';
    if (form.years === '' || +form.years < 0) e.years = 'Enter years (0 if under a year)';
    if (!form.age || +form.age < 16 || +form.age > 100) e.age = 'Enter a valid age';
    if (!form.offer || +form.offer < 0) e.offer = 'Enter the offered amount';
    if (!form.reason) e.reason = 'Select a reason';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    const result = window.SC.getVerdict(
      +form.salary, +form.years, +form.age, +form.offer,
      form.reason, form.discrimination
    );
    onCalculate({ inputs: form, result });
  };

  return (
    <form className="calc card" onSubmit={submit} noValidate>
      <div className="calc-header">
        <span className="eyebrow">Free calculator</span>
        <h3 className="h3" style={{marginTop: 6}}>Check your offer</h3>
        <p className="muted" style={{margin: '6px 0 0', fontSize: 14}}>
          Six questions. Sixty seconds. No email required.
        </p>
      </div>

      <div className="calc-body">
        <div className="grid-2">
          <Field label="Annual salary" error={errors.salary}>
            <div className="input-wrap">
              <span className="input-prefix">£</span>
              <input className="input" type="number" inputMode="numeric"
                placeholder="42,000" value={form.salary}
                onChange={e => update('salary', e.target.value)}/>
            </div>
          </Field>
          <Field label="Years at employer" error={errors.years}>
            <div className="input-wrap">
              <input className="input" type="number" inputMode="numeric" step="0.5"
                placeholder="6" value={form.years}
                onChange={e => update('years', e.target.value)}/>
            </div>
          </Field>
          <Field label="Your age when leaving" error={errors.age}>
            <div className="input-wrap">
              <input className="input" type="number" inputMode="numeric"
                placeholder="38" value={form.age}
                onChange={e => update('age', e.target.value)}/>
            </div>
          </Field>
          <Field label="Settlement offered" error={errors.offer}>
            <div className="input-wrap">
              <span className="input-prefix">£</span>
              <input className="input" type="number" inputMode="numeric"
                placeholder="18,000" value={form.offer}
                onChange={e => update('offer', e.target.value)}/>
            </div>
          </Field>
        </div>

        <Field label="Reason for leaving" error={errors.reason}>
          <div className="input-wrap">
            <select className="select" value={form.reason}
              onChange={e => update('reason', e.target.value)}>
              {REASONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
        </Field>

        <Field label={
          <>
            Any discrimination involved?
            <span className="tip" data-tip="e.g. age, gender, race, disability, pregnancy">?</span>
          </>
        }>
          <div className="pill-radio" role="radiogroup">
            {[['no','No'],['yes','Yes'],['not_sure','Not sure']].map(([v,l]) => (
              <button key={v} type="button"
                aria-pressed={form.discrimination === v}
                onClick={() => update('discrimination', v)}>{l}</button>
            ))}
          </div>
        </Field>
      </div>

      <div className="calc-footer">
        <button type="submit" className="btn btn-accent btn-block">
          Calculate my estimate →
        </button>
        <p className="calc-disclaimer">
          Estimate only. Not legal advice. Based on UK statutory rates 2024/25.
        </p>
      </div>
    </form>
  );
}

function Field({ label, error, children }) {
  return (
    <div className="field">
      <label className="field-label">{label}</label>
      {children}
      {error && <span className="field-error">{error}</span>}
    </div>
  );
}

window.Calculator = Calculator;
