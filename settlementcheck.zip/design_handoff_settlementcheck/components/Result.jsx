/* Result card + lead capture */
function ResultCard({ payload, onReset }) {
  const { inputs, result } = payload;
  const { verdict, minimum, typicalLow, typicalHigh, redundancy, notice, discriminationFlag } = result;
  const offer = +inputs.offer;

  const config = {
    BELOW_MINIMUM: {
      cls: 'verdict-below_minimum',
      tag: 'tag-crimson',
      tagText: 'Action recommended',
      icon: '⚠',
      heading: 'Your offer appears below the legal minimum',
      body: `Based on your inputs, your statutory minimum entitlement is approximately ${window.SC.fmtGBP(minimum)}. Your offer of ${window.SC.fmtGBP(offer)} appears to fall short of this floor. A solicitor should review immediately.`,
    },
    BELOW_TYPICAL: {
      cls: 'verdict-below_typical',
      tag: 'tag-amber',
      tagText: 'Likely below typical',
      icon: '↓',
      heading: 'Your offer may be below the typical range',
      body: `For circumstances similar to yours, settlements typically fall between ${window.SC.fmtGBP(typicalLow)} and ${window.SC.fmtGBP(typicalHigh)}. Many employees successfully negotiate higher with legal support.`,
    },
    WITHIN_RANGE: {
      cls: 'verdict-within_range',
      tag: 'tag-sage',
      tagText: 'Within range',
      icon: '✓',
      heading: 'Your offer appears within the typical range',
      body: `For circumstances similar to yours, settlements typically fall between ${window.SC.fmtGBP(typicalLow)} and ${window.SC.fmtGBP(typicalHigh)}. A solicitor can confirm whether the structure (tax-free portion, references, restrictive covenants) is favourable.`,
    },
    ABOVE_TYPICAL: {
      cls: 'verdict-above_typical',
      tag: 'tag-sage',
      tagText: 'Above typical',
      icon: '↑',
      heading: 'Your offer appears above the typical range',
      body: `Your offer of ${window.SC.fmtGBP(offer)} sits above the typical band of ${window.SC.fmtGBP(typicalLow)}–${window.SC.fmtGBP(typicalHigh)}. A solicitor should still review the structure and any waivers before you sign.`,
    },
  }[verdict];

  return (
    <div className="results">
      <div className="results-head">
        <button className="btn-link" onClick={onReset}>← Adjust calculator</button>
        <span className="eyebrow">Your estimate</span>
      </div>

      <div className={'verdict ' + config.cls}>
        <div className="verdict-row">
          <span className={'verdict-tag ' + config.tag}>{config.icon} {config.tagText}</span>
        </div>
        <h2 className="h2 verdict-heading">{config.heading}</h2>
        <p className="verdict-body">{config.body}</p>

        <div className="verdict-numbers">
          <div>
            <div className="eyebrow">Your offer</div>
            <div className="big-num">{window.SC.fmtGBP(offer)}</div>
          </div>
          <div className="vsep" aria-hidden="true"></div>
          <div>
            <div className="eyebrow">Typical range</div>
            <div className="big-num">{window.SC.fmtGBP(typicalLow)} – {window.SC.fmtGBP(typicalHigh)}</div>
          </div>
        </div>
      </div>

      {discriminationFlag && (
        <div className="info-box" style={{marginTop: 20}}>
          <strong style={{color: 'var(--info)'}}>⚡ Potential discrimination flagged.</strong>{' '}
          Discrimination claims are <em>uncapped</em> in UK employment tribunals and can substantially increase settlement value. A specialist solicitor must assess this with you.
        </div>
      )}

      <div className="card card-pad" style={{marginTop: 28}}>
        <h3 className="h3" style={{marginBottom: 18}}>How we calculated this</h3>
        <table className="breakdown">
          <tbody>
            <tr>
              <th>Statutory redundancy</th>
              <td className="value">{window.SC.fmtGBP(redundancy)}</td>
            </tr>
            <tr>
              <th>Statutory notice pay</th>
              <td className="value">{window.SC.fmtGBP(notice)}</td>
            </tr>
            <tr className="highlight">
              <th>Estimated minimum</th>
              <td className="value">{window.SC.fmtGBP(minimum)}</td>
            </tr>
            <tr>
              <th>Typical low</th>
              <td className="value">{window.SC.fmtGBP(typicalLow)}</td>
            </tr>
            <tr>
              <th>Typical high</th>
              <td className="value">{window.SC.fmtGBP(typicalHigh)}</td>
            </tr>
            <tr className="highlight">
              <th>Your offer</th>
              <td className="value">{window.SC.fmtGBP(offer)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <LeadForm payload={payload}/>

      <p className="results-disclaimer">
        Estimate based on published UK statutory rates (weekly cap £643, 2024/25). Not legal advice. SettlementCheck connects you with SRA-regulated solicitors and is not a law firm.
      </p>
    </div>
  );
}

function LeadForm({ payload }) {
  const [form, setForm] = React.useState({
    first_name: '', email: '', phone: '', contact_time: 'Morning', consent: false,
  });
  const [errors, setErrors] = React.useState({});
  const [status, setStatus] = React.useState('idle'); // idle | submitting | success

  const update = (k, v) => {
    setForm(f => ({...f, [k]: v}));
    if (errors[k]) setErrors(e => ({...e, [k]: undefined}));
  };

  const submit = async (ev) => {
    ev.preventDefault();
    const e = {};
    if (!form.first_name) e.first_name = 'Required';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.phone || form.phone.length < 7) e.phone = 'Enter a phone number';
    if (!form.consent) e.consent = 'Please consent to be contacted';
    setErrors(e);
    if (Object.keys(e).length) return;

    setStatus('submitting');
    // Simulated submission — would POST to https://formspree.io/f/YOUR_FORMSPREE_ID
    await new Promise(r => setTimeout(r, 700));
    setStatus('success');
  };

  if (status === 'success') {
    return (
      <div className="card card-pad lead-success">
        <div className="success-mark">✓</div>
        <h3 className="h3">Thank you, {form.first_name}.</h3>
        <p className="muted" style={{maxWidth: '52ch'}}>
          We've received your details. A vetted employment solicitor will call you on{' '}
          <strong>{form.phone}</strong> within <strong>24 hours</strong> ({form.contact_time.toLowerCase()} preferred). The advice is free — your employer covers the cost.
        </p>
      </div>
    );
  }

  return (
    <form className="card card-pad lead-form" onSubmit={submit} noValidate>
      <div>
        <span className="eyebrow">Step 2 of 2</span>
        <h3 className="h3" style={{margin: '6px 0 6px'}}>Get free advice from a vetted solicitor</h3>
        <p className="muted" style={{margin: 0, maxWidth: '54ch'}}>
          Your employer covers the legal fees (typically £350–750). It costs you nothing.
        </p>
      </div>

      <div className="grid-2">
        <Field label="First name" error={errors.first_name}>
          <div className="input-wrap">
            <input className="input" value={form.first_name}
              onChange={e => update('first_name', e.target.value)} placeholder="Alex"/>
          </div>
        </Field>
        <Field label="Email" error={errors.email}>
          <div className="input-wrap">
            <input className="input" type="email" value={form.email}
              onChange={e => update('email', e.target.value)} placeholder="alex@example.com"/>
          </div>
        </Field>
        <Field label="Phone" error={errors.phone}>
          <div className="input-wrap">
            <input className="input" type="tel" value={form.phone}
              onChange={e => update('phone', e.target.value)} placeholder="07…"/>
          </div>
        </Field>
        <Field label="Preferred contact time">
          <div className="pill-radio" role="radiogroup">
            {['Morning', 'Afternoon', 'Evening'].map(t => (
              <button key={t} type="button"
                aria-pressed={form.contact_time === t}
                onClick={() => update('contact_time', t)}>{t}</button>
            ))}
          </div>
        </Field>
      </div>

      <label className="consent">
        <input type="checkbox" checked={form.consent}
          onChange={e => update('consent', e.target.checked)}/>
        <span>
          I consent to SettlementCheck sharing my details with up to 3 vetted SRA-regulated solicitors so they may contact me about my settlement.
        </span>
      </label>
      {errors.consent && <span className="field-error">{errors.consent}</span>}

      <button type="submit" className="btn btn-accent btn-block" disabled={status === 'submitting'}>
        {status === 'submitting' ? 'Submitting…' : 'Get my free solicitor match →'}
      </button>
    </form>
  );
}

window.ResultCard = ResultCard;
