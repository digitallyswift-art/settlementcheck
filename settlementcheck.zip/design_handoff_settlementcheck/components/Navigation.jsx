/* Navigation */
function Navigation() {
  const [open, setOpen] = React.useState(false);
  return (
    <header className="nav">
      <div className="container nav-inner">
        <a href="#top" className="logo" aria-label="SettlementCheck home">
          <span className="logo-mark" aria-hidden="true">
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
              <rect x="1" y="1" width="20" height="20" rx="4" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M6 11.5L9.5 15L16 7.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </span>
          <span className="logo-word">
            <span style={{color: 'var(--coral)'}}>Settlement</span><span>Check</span>
          </span>
        </a>
        <nav className="nav-links" aria-label="Primary">
          <a href="#how">How it works</a>
          <a href="#solicitors">For solicitors</a>
          <a href="#about">About</a>
        </nav>
        <div className="nav-cta">
          <a href="#calculator" className="btn btn-ghost btn-sm">Check my offer</a>
          <a href="#calculator" className="btn btn-primary btn-sm">Find a solicitor →</a>
        </div>
        <button className="nav-burger" aria-label="Menu" onClick={() => setOpen(!open)}>
          <span/><span/><span/>
        </button>
      </div>
      {open && (
        <div className="nav-mobile">
          <a href="#how" onClick={() => setOpen(false)}>How it works</a>
          <a href="#solicitors" onClick={() => setOpen(false)}>For solicitors</a>
          <a href="#about" onClick={() => setOpen(false)}>About</a>
          <a href="#calculator" onClick={() => setOpen(false)} className="btn btn-primary">Find a solicitor →</a>
        </div>
      )}
    </header>
  );
}

window.Navigation = Navigation;
