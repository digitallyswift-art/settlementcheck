/* Page sections */
function Hero({ onCalculate }) {
  return (
    <section className="hero" id="top">
      <div className="container hero-inner">
        <div className="hero-text fade-up">
          <span className="pill"><span className="dot"/> Free · Confidential · No obligation</span>
          <h1 className="h1">
            Is your settlement<br/>offer <em style={{fontStyle: 'italic', color: 'var(--coral)'}}>fair</em>?
          </h1>
          <p className="lead">
            Find out in 60 seconds. Our free calculator estimates whether your employer's offer falls below, within, or above the typical UK range — then connects you with a specialist solicitor. Your employer pays their legal fees.
          </p>
          <div className="trust-row">
            <span className="trust-item"><span className="stars">★★★★★</span> <strong>4.9</strong>/5</span>
            <span className="sep" aria-hidden="true">·</span>
            <span className="trust-item"><strong>2,400+</strong> employees helped</span>
            <span className="sep" aria-hidden="true">·</span>
            <span className="trust-item"><strong>£0</strong> cost to you</span>
          </div>
        </div>

        <div id="calculator" className="hero-calc fade-up" style={{transitionDelay: '90ms'}}>
          <Calculator onCalculate={onCalculate}/>
        </div>
      </div>
    </section>
  );
}

function StatBar() {
  const items = [
    {n: '2,400+', l: 'Employees helped'},
    {n: '£0', l: 'Cost to you'},
    {n: '24 hrs', l: 'Solicitor response'},
    {n: '4.9★', l: 'Average rating'},
  ];
  return (
    <section className="statbar">
      <div className="container statbar-inner">
        {items.map((s, i) => (
          <div key={i} className="stat fade-up" style={{transitionDelay: `${i*60}ms`}}>
            <div className="stat-num">{s.n}</div>
            <div className="stat-label">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    {n: '01', t: 'Check your offer', d: 'Enter six details and get an instant estimate of whether your offer is fair, below, or above the typical UK range — based on statutory rates.'},
    {n: '02', t: 'Match with a solicitor', d: 'We introduce you to 2–3 vetted, SRA-regulated employment solicitors in your region within 24 hours. You decide who to speak with.'},
    {n: '03', t: 'Get advice — free to you', d: 'Your employer is legally required to cover your legal fees (typically £350–750). You pay absolutely nothing for the advice.'},
  ];
  return (
    <section id="how" className="section">
      <div className="container">
        <div className="section-head fade-up">
          <span className="eyebrow">How it works</span>
          <h2 className="h2">Three steps. Sixty seconds. Zero cost.</h2>
          <p className="lead">From a quick check to a vetted solicitor on the phone — without paying a penny yourself.</p>
        </div>

        <div className="how-grid">
          {steps.map((s, i) => (
            <article key={i} className="how-card fade-up" style={{transitionDelay: `${i*80}ms`}}>
              <div className="how-num">{s.n}</div>
              <h3 className="h3" style={{marginTop: 28}}>{s.t}</h3>
              <p className="muted" style={{marginTop: 12, fontSize: 15}}>{s.d}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function TrustSection() {
  const items = [
    {t: 'Genuinely independent', d: 'We don\'t represent any single firm. The panel is curated, the introductions are unbiased.'},
    {t: 'Your employer pays', d: 'Under UK practice, employers contribute £350–750 toward your independent legal advice on a settlement.'},
    {t: 'Vetted specialists only', d: 'Every panel solicitor is SRA-regulated and demonstrably specialised in employment settlements.'},
    {t: '24-hour response', d: 'Every firm on the panel commits to making contact within 24 hours of an introduction.'},
  ];
  return (
    <section id="about" className="section trust-section">
      <div className="container">
        <div className="trust-grid">
          <div className="section-head fade-up">
            <span className="eyebrow">Why SettlementCheck</span>
            <h2 className="h2">An introduction service built for the employee, not the employer.</h2>
            <p className="lead">Most settlement enquiries route to firms that pay for the lead. We don't take payment from firms — only from a small monthly subscription they pay for panel access. That keeps the introduction honest.</p>
          </div>
          <div className="trust-list fade-up">
            {items.map((it, i) => (
              <div key={i} className="trust-item-card">
                <div className="trust-mark" aria-hidden="true">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M2 7.5L6 11L12 3.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div>
                  <div className="trust-t">{it.t}</div>
                  <div className="trust-d">{it.d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const items = [
    {q: 'Does it cost me anything?', a: 'No. Your employer is required to contribute to your legal fees (typically £350–750). You pay nothing — that is the standard arrangement on a UK settlement agreement.'},
    {q: 'Do I legally need a solicitor?', a: 'Yes. Under Section 203 of the Employment Rights Act 1996, a settlement agreement is only legally binding if you have received independent legal advice from a qualified, insured solicitor. You cannot waive your rights without it.'},
    {q: 'How accurate is the calculator?', a: 'The calculator gives a general estimate based on UK statutory rates and benchmarks from settlements we\'ve seen. It is not legal advice — your circumstances may justify substantially more or less, and only a solicitor reviewing your contract and reason for leaving can tell you.'},
    {q: 'How quickly will a solicitor contact me?', a: 'All panel solicitors commit to responding within 24 hours of an introduction. Most reach out the same business day, often within a couple of hours during working hours.'},
    {q: 'What if I want to negotiate a higher amount?', a: 'Many employees do successfully negotiate more once a solicitor reviews their circumstances. A specialist will assess whether factors like length of service, discrimination, whistleblowing, or contract breaches justify a higher offer.'},
    {q: 'Is my information shared?', a: 'Only with the small panel of solicitors you choose to be introduced to — never with employers, recruiters, or third parties. You can withdraw at any point.'},
  ];
  const [open, setOpen] = React.useState(0);
  return (
    <section className="section faq-section">
      <div className="container faq-inner">
        <div className="section-head fade-up" style={{maxWidth: 480}}>
          <span className="eyebrow">Common questions</span>
          <h2 className="h2">What people ask before they start.</h2>
          <p className="lead">Six things almost every employee wants to know before clicking "calculate."</p>
        </div>
        <div className="faq-list fade-up">
          {items.map((it, i) => (
            <details key={i} className="faq-item" open={open === i}
              onToggle={(e) => { if (e.target.open) setOpen(i); }}>
              <summary className="faq-q">
                <span>{it.q}</span>
                <span className="icon" aria-hidden="true">+</span>
              </summary>
              <div className="faq-a">{it.a}</div>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTABanner() {
  return (
    <section className="cta-banner">
      <div className="container cta-inner fade-up">
        <div>
          <h2 className="h2" style={{color: '#fff', maxWidth: 18 + 'ch'}}>Not sure if your offer is fair?</h2>
          <p style={{color: 'rgba(255,255,255,0.78)', fontSize: 18, marginTop: 12, maxWidth: '46ch'}}>
            Use the free calculator. It takes about a minute, and there's no obligation to proceed.
          </p>
        </div>
        <a href="#calculator" className="btn btn-accent">Check my offer now →</a>
      </div>
    </section>
  );
}

function SiteFooter() {
  return (
    <footer className="site">
      <div className="container" style={{paddingTop: 80, paddingBottom: 40}}>
        <div className="footer-grid">
          <div>
            <div className="footer-logo">
              <span style={{color: 'var(--coral)'}}>Settlement</span>Check
            </div>
            <p style={{maxWidth: '34ch', fontSize: 14, lineHeight: 1.6}}>
              Free settlement agreement advice for UK employees. Your employer pays the legal fees.
            </p>
            <p className="small" style={{marginTop: 24, maxWidth: '38ch'}}>
              SettlementCheck is an introduction service, not a law firm. We are not regulated by the SRA. Solicitors on our panel are independently SRA-regulated.
            </p>
          </div>
          <div>
            <h4>For employees</h4>
            <ul>
              <li><a href="#how">How it works</a></li>
              <li><a href="#calculator">Check your offer</a></li>
              <li><a href="#about">FAQs</a></li>
            </ul>
          </div>
          <div>
            <h4>For solicitors</h4>
            <ul>
              <li><a href="#solicitors">Join our panel</a></li>
              <li><a href="#solicitors">How it works for firms</a></li>
            </ul>
          </div>
          <div>
            <h4>Legal</h4>
            <ul>
              <li><a href="#">Privacy policy</a></li>
              <li><a href="#">Terms of use</a></li>
              <li><a href="#">Disclaimer</a></li>
            </ul>
          </div>
        </div>
        <hr className="footer-rule"/>
        <div className="footer-bottom">
          <span className="small">© 2026 SettlementCheck Ltd · Registered in England</span>
          <span className="small">settlementcheck.co.uk</span>
        </div>
      </div>
    </footer>
  );
}

window.Hero = Hero;
window.StatBar = StatBar;
window.HowItWorks = HowItWorks;
window.TrustSection = TrustSection;
window.FAQ = FAQ;
window.CTABanner = CTABanner;
window.SiteFooter = SiteFooter;
