# Handoff: SettlementCheck — Full Website

**Repo:** https://github.com/digitallyswift-art/settlementcheck  
**Target stack:** Next.js 14 (App Router) · TypeScript · Tailwind CSS · Framer Motion · Formspree  
**Deployment:** Cloudflare Pages (`output: 'export'`)

---

## About the Design Files

The files in this bundle are **high-fidelity HTML prototypes** — not production code to ship directly. They demonstrate the intended look, behaviour, and interaction model of the site. Your job is to **recreate this design faithfully inside the Next.js / Tailwind codebase**, using the component architecture, routing, and conventions appropriate to that stack.

Open `SettlementCheck.html` in a browser to see the full working prototype. The calculator is live and produces real results.

---

## Fidelity

**High-fidelity.** The prototype shows final colours, typography, spacing, interactions, and copy. Recreate it pixel-accurately using Tailwind theme tokens derived from the values below. The calculator logic in `calculator.js` is production-ready and should be moved verbatim to `lib/calculator.ts`.

---

## Design System

### Colours

Configure these as Tailwind theme extensions in `tailwind.config.js`:

```js
colors: {
  ink: {
    DEFAULT: '#0B1F3A',
    2:       '#1A2F4E',
  },
  paper: {
    DEFAULT: '#F7F4EE',
    2:       '#EFEAE0',
  },
  card:         '#FFFFFF',
  rule: {
    DEFAULT:  '#E2DCCE',
    strong:   '#C9C0AC',
  },
  muted: {
    DEFAULT:  '#5B6577',
    2:        '#8A93A3',
  },
  coral: {
    DEFAULT:  '#D9603B',
    ink:      '#B14A28',
  },
  sage: {
    DEFAULT:  '#4F7060',
    tint:     '#E8EFE9',
  },
  amber: {
    DEFAULT:  '#B5802A',
    tint:     '#F4ECD7',
  },
  crimson: {
    DEFAULT:  '#A8341F',
    tint:     '#F4E1DC',
  },
  info: {
    DEFAULT:  '#2F4F7A',
    tint:     '#E2EAF3',
  },
}
```

### Typography

```js
// tailwind.config.js — fontFamily
fontFamily: {
  serif: ['"Source Serif 4"', '"Source Serif Pro"', 'Georgia', 'serif'],
  sans:  ['Inter', '-apple-system', '"Helvetica Neue"', 'Arial', 'sans-serif'],
  mono:  ['"JetBrains Mono"', 'ui-monospace', '"SF Mono"', 'Menlo', 'monospace'],
}
```

Google Fonts import (via `next/font/google`):
- **Source Serif 4** — weights 400, 460, 500 · italic 420 · `opsz` 8..60
- **Inter** — weights 400, 500, 600
- **JetBrains Mono** — weights 400, 500

#### Type scale

| Token   | Family  | Size (clamp)           | Weight | Line-height | Letter-spacing |
|---------|---------|------------------------|--------|-------------|----------------|
| H1      | Serif   | clamp(40px, 5.6vw, 68px) | 420    | 1.04        | -0.022em       |
| H2      | Serif   | clamp(30px, 3.2vw, 44px) | 420    | 1.10        | -0.018em       |
| H3      | Serif   | 22px                   | 460    | 1.25        | -0.010em       |
| Eyebrow | Sans    | 12px                   | 500    | —           | +0.14em, uppercase |
| Lead    | Sans    | 18px                   | 400    | 1.55        | —              |
| Body    | Sans    | 16px                   | 400    | 1.55        | —              |
| Small   | Sans    | 12–13px                | 400    | 1.60        | —              |
| Stat    | Serif   | 44px                   | 420    | 1.00        | -0.020em       |

### Spacing

```js
// tailwind.config.js — extend spacing
spacing: {
  section:   '96px',   // section padding top/bottom
  sectionSm: '64px',   // tighter section variant
  container: '1200px', // max-width
  gutter:    '32px',   // container horizontal padding (20px mobile)
}
```

### Border radius

| Token | Value |
|-------|-------|
| xs    | 4px   |
| sm    | 6px   |
| md    | 10px  |
| lg    | 14px  |
| pill  | 999px |

### Shadows

No box shadows. Cards use `border: 1px solid var(--rule)` only. This is intentional — the design language is flat and editorial.

---

## File Structure

```
app/
  page.tsx                    ← Homepage (hero + all sections)
  results/page.tsx            ← Results page (reads URL params)
  for-solicitors/page.tsx     ← Solicitor acquisition page
  how-it-works/page.tsx       ← Expanded 3-step + FAQ + CTA
  privacy/page.tsx
  terms/page.tsx
  disclaimer/page.tsx
  not-found.tsx
components/
  Navigation.tsx
  Calculator.tsx              ← The hero widget
  ResultCard.tsx              ← Verdict display
  LeadCaptureForm.tsx         ← Step 2 form (Formspree)
  StatBar.tsx
  HowItWorks.tsx
  TrustSection.tsx
  FAQ.tsx
  CTABanner.tsx
  Footer.tsx
lib/
  calculator.ts               ← Copy verbatim from calculator.js
tailwind.config.js
next.config.js
```

---

## Screens

### 1. Homepage (`app/page.tsx`)

**Overall layout:** Single scrolling page. Sticky nav. All sections stacked vertically with `section` padding.

#### Navigation
- Position: `sticky top-0 z-50`
- Height: `68px`
- Background: `rgba(247, 244, 238, 0.88)` + `backdrop-blur`
- Border-bottom: `1px solid rule`
- Layout: flex, space-between, 3 zones: logo | centre links | right CTAs
- **Logo:** SVG checkmark icon (22×22, `coral`) + wordmark "Settlement" (`coral`) + "Check" (`ink`), font-serif 20px weight-460
- **Nav links (desktop):** "How it works" | "For Solicitors" | "About" — font-sans 14px, hover `coral-ink`
- **Right CTAs:** ghost button "Check my offer" + primary button "Find a solicitor →"
- **Mobile (≤900px):** links + CTAs hidden, burger button shown, mobile dropdown below nav

#### Hero section
- Layout: CSS grid, `grid-cols-[1.05fr_1fr]`, gap `64px`, align-items center
- Padding: `56px 0 40px`
- Background: paper + two radial gradients (coral tint top-right, ink tint bottom-left — very subtle, opacity ~0.06)
- **Left column** (max-width 560px), flex col gap-24:
  - Pill badge: `border: 1px solid rule-strong`, pill radius, 12px font, "· Free · Confidential · No obligation" with 6px coral dot
  - H1 with italic "fair" in coral
  - Lead paragraph (18px, muted, max 56ch)
  - Trust row: `border-top: 1px solid rule`, flex gap-14, 14px muted — stars in coral, strong values in ink
- **Right column:** Calculator card (see Calculator component)
- **Mobile:** single column, calc below text

#### Stats Bar
- Background: `paper-2`, borders top+bottom `rule`
- Grid: `grid-cols-4`, padding `36px 0`
- Each stat: left-border `rule-strong` (except first), `padding-left: 24px`
- Stat number: font-serif 44px weight-420 letter-spacing -0.02em
- Stat label: 13px muted, margin-top 8px
- **Mobile:** `grid-cols-2`

#### How It Works
- Section padding default
- Section header (eyebrow + H2 + lead), max-width 640px
- Grid: `grid-cols-3` gap-24, margin-top 56px
- **Card:** white, border rule, radius lg, padding 32px, hover border-color `rule-strong`
- Large step number: font-serif 56px coral, weight 420, letter-spacing -0.04em
- H3 title at margin-top 28px
- Body 15px muted at margin-top 12px

#### Trust Section
- Background: `paper-2`, borders top+bottom
- Grid: `grid-cols-[1fr_1.05fr]` gap-80
- Left: section header (eyebrow + H2 + lead paragraph)
- Right: list of 4 items, each `grid-cols-[28px_1fr]` gap-16, border-bottom rule
  - Mark: 28px circle, ink background, white SVG checkmark
  - Title: font-serif 19px ink
  - Body: 15px muted, line-height 1.55

#### FAQ
- Background: paper
- Grid: `grid-cols-[1fr_1.4fr]` gap-80
- Left: section header
- Right: `<details>` accordion list, border-top rule
- Each `<details>`: border-bottom rule
- Summary (question): font-serif 19px weight-460, flex space-between, padding `24px 0`
- Icon: 28px circle, border `rule-strong`, `+` symbol — rotates 45° when open, fills ink
- Answer: 15px muted, line-height 1.65, padding-bottom 24px, max-width 68ch

#### CTA Banner
- Background: `ink`
- Radial gradient overlay: coral tint at 90% 50% ~18% opacity
- Grid: `grid-cols-[1.4fr_auto]` gap-40 align-items center, padding `88px 32px`
- H2 white, lead white/78%, button: coral accent

#### Footer
- Background: `ink`
- Padding: `80px 0 40px`
- Grid: `grid-cols-[1.4fr_1fr_1fr_1fr]` gap-56
- Logo: font-serif 22px white, "Settlement" in coral
- Tagline: 14px rgba(255,255,255,0.78), max 34ch
- Disclaimer: 12px rgba(255,255,255,0.55), max 38ch, margin-top 24px
- Column headings: 12px uppercase tracking-wide white, margin-bottom 16px
- Links: 14px rgba(255,255,255,0.78), flex col gap-10
- Footer rule: rgba(255,255,255,0.1) border
- Bottom bar: flex space-between, 12px rgba(255,255,255,0.55)

---

### 2. Results Screen (`app/results/page.tsx`)

**Trigger:** Calculator form submits by pushing to `/results` with all values as URL search params:  
`/results?salary=42000&years=6&age=38&offer=18000&reason=redundancy&discrimination=no`

Read params with `useSearchParams()`. Run `getVerdict()` from `lib/calculator.ts`. Display results client-side.

**Layout:** `max-width: 900px`, centred, padding `56px 0 96px`

#### Verdict Card

Four states — apply class to the outer card:

| Verdict | Card background | Card border | Tag colour |
|---------|----------------|-------------|------------|
| BELOW_MINIMUM | `crimson-tint` | `#D9A99E` | `crimson` text on white |
| BELOW_TYPICAL | `amber-tint` | `#E0CB94` | `amber` text on white |
| WITHIN_RANGE | `sage-tint` | `#BCD0BF` | `sage` text on white |
| ABOVE_TYPICAL | `sage-tint` | `#BCD0BF` | `sage` text on white |

Verdict headings:
- `BELOW_MINIMUM`: "⚠ Your offer appears below the legal minimum"
- `BELOW_TYPICAL`: "Your offer may be below the typical range"
- `WITHIN_RANGE`: "✓ Your offer appears within the typical range"
- `ABOVE_TYPICAL`: "Your offer appears above the typical range"

Numbers row (inside verdict card):
- Two columns: "Your offer" | "Typical range" separated by `1px solid rgba(ink,0.12)` vertical rule
- Numbers: font-serif 28px ink, letter-spacing -0.015em

#### Discrimination Flag
- If `discrimination === 'yes' || 'not_sure'` show info box
- Background: `info-tint`, border `#B9CADD`, radius md, padding `16px 18px`, 14px info colour
- Text: "⚡ Potential discrimination flagged. Discrimination claims are uncapped…"

#### Breakdown Table
- White card, border rule, radius lg
- Table: full width, border-collapse
- `th`: 12px uppercase tracking, muted, padding `14px 16px`, border-bottom rule
- `td.value`: font-mono, text-right, tabular-nums
- Highlighted rows (estimated minimum + your offer): `background: paper`, font-weight 500

#### Lead Capture Form
- White card, padding 28px, radius lg, margin-top 24px, flex col gap-20
- Eyebrow "Step 2 of 2" + H3 + lead
- Grid 2-col: first name | email | phone | contact time pill-radio
- Consent checkbox: `grid-cols-[18px_1fr]` gap-12, 13px muted, accent-color ink
- Submit: full-width coral accent button "Get my free solicitor match →"
- Formspree endpoint: `https://formspree.io/f/YOUR_FORMSPREE_ID`
- Include hidden fields: `verdict`, `offer_amount`, `salary`, `years_service`
- Success state: sage-tint card, 56px circle checkmark in sage, H3 + confirmation text

---

### 3. For Solicitors (`app/for-solicitors/page.tsx`)

- H1: "Receive qualified settlement agreement leads"
- Lead: "Every enquiry has completed our calculator and is motivated and informed."
- Three benefit cards (same style as How It Works cards):
  - "Pre-qualified leads" — "Each person has completed the calculator and shown intent."
  - "Your geography only" — "We match by postcode region. No leads outside your coverage."
  - "No minimum spend" — "Panel subscription is flat-rate. No per-lead charges."
- Application form card: firm name | contact name | email | phone | geographic coverage | SRA regulated (checkbox)
- Submit to Formspree with hidden field `form_type = "solicitor_application"`
- Same page structure as homepage (nav + footer)

---

### 4. How It Works (`app/how-it-works/page.tsx`)

- Full-page version of the 3-step grid (expanded descriptions)
- FAQ section (same accordion component)
- CTA Banner at bottom
- No hero calculator

---

### 5. Legal Pages

All three (`/privacy`, `/terms`, `/disclaimer`) share a layout:
- Nav + footer
- `max-width: 720px` centred container
- H1 + `<time>` last updated
- Prose body: H2 sections, `<p>` paragraphs, 16px body text

---

## Components

### `<Calculator>`

**Props:** `onCalculate: (payload: {inputs, result}) => void`

Six inputs matching this layout:
```
[ Annual salary £ ] [ Years at employer ]
[ Age when leaving ] [ Settlement offered £ ]
[ Reason for leaving (select) ]
[ Discrimination? (pill radio: No | Yes | Not sure) ]
[ Calculate my estimate → ]  (coral accent button, full width)
```

Validation (inline error messages, 12px crimson, below the field):
- `salary`: required, ≥ 1000
- `years`: required, ≥ 0
- `age`: required, 16–100
- `offer`: required, ≥ 0
- `reason`: required (non-empty)

On valid submit: call `onCalculate` with `{ inputs, result: getVerdict(...) }`

Calculator card has 3 zones:
1. Header (paper-2 gradient bg, border-bottom rule) — eyebrow + H3 + subtext
2. Body (padding 24px 28px, flex col gap-18) — all inputs
3. Footer (padding 0 28px 28px) — submit button + disclaimer

Input field anatomy:
- Wrapper: `background: paper`, `border: 1px solid rule`, radius sm, transition to `border-color: ink` + `background: white` on `:focus-within`
- `£` prefix: font-mono 14px muted, padding-left 14px
- `<input>`: no border, transparent bg, outline none, padding 12px 14px, 15px ink

Pill radio (discrimination field):
- Wrapper: `background: paper`, `border: 1px solid rule`, radius pill, padding 3px
- Buttons: radius pill, 8px 16px padding, 13px 500 weight — selected: `background: ink`, `color: white`

Tooltip (`?` icon next to discrimination label):
- 16px circle, border rule-strong, 10px font
- CSS `::after` tooltip on hover: ink bg, white text, above the icon

### `<ResultCard>`

**Props:** `payload: {inputs, result}`, `onReset: () => void`

Displays verdict card + discrimination flag + breakdown table + `<LeadCaptureForm>` + disclaimer.

### `<LeadCaptureForm>`

**Props:** `payload: {inputs, result}` (for hidden fields)

Submits via Formspree `fetch` POST with `Accept: application/json`.  
Success state: replace form with confirmation card.

### `<FAQ>`

Uses native `<details>` / `<summary>`. Track `open` state to rotate the `+` icon.

### `<StatBar>`

Four stats, driven by a static array — no dynamic data.

---

## Interactions & Animations

Use **Framer Motion** for scroll animations. Pattern: `fadeUp` variant.

```ts
// variants/fadeUp.ts
export const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.48, ease: [0.22, 0.61, 0.36, 1] } },
}
```

Apply to: hero text, hero calculator card (100ms delay), stat items (60ms stagger), how-it-works cards (80ms stagger), trust items, FAQ section.

Use `whileInView` with `once: true` and `margin: "0px 0px -40px 0px"` viewport.

Other transitions:
- Nav links hover: `color` 160ms ease
- Button hover: `background` 180ms ease (primary/accent) or `background + border-color` (ghost)
- Input focus: `border-color + background` 160ms ease
- FAQ icon: `transform rotate(45deg)` 220ms ease + `background + color` 160ms ease

---

## Calculator Logic

Copy `calculator.js` verbatim to `lib/calculator.ts`. Add TypeScript types:

```ts
export type Reason = 'redundancy' | 'dismissal' | 'resignation' | 'mutual' | 'other';
export type Discrimination = 'no' | 'yes' | 'not_sure';
export type Verdict = 'BELOW_MINIMUM' | 'BELOW_TYPICAL' | 'WITHIN_RANGE' | 'ABOVE_TYPICAL';

export interface VerdictResult {
  verdict: Verdict;
  minimum: number;
  typicalLow: number;
  typicalHigh: number;
  redundancy: number;
  notice: number;
  discriminationFlag: boolean;
}
```

Constants:
```ts
const WEEKLY_PAY_CAP = 643; // UK 2024/25 statutory rate
```

The three exported functions:
- `calcRedundancy(salary, years, age)` — age multiplier: <22 → 0.5×, 22–40 → 1×, >40 → 1.5×; capped at 20 years service
- `calcNotice(salary, years)` — 0 weeks if <1 month, 1 week if <2yr, `min(floor(years), 12)` weeks otherwise
- `getVerdict(salary, years, age, offer, reason, discrimination)` — returns `VerdictResult`

---

## Formspree Integration

Endpoint: `https://formspree.io/f/YOUR_FORMSPREE_ID`  
Replace `YOUR_FORMSPREE_ID` with the actual form ID from your Formspree account.

Lead capture POST body:
```json
{
  "first_name": "Alex",
  "email": "alex@example.com",
  "phone": "07700900000",
  "contact_time": "Morning",
  "verdict": "BELOW_TYPICAL",
  "offer_amount": 18000,
  "salary": 42000,
  "years_service": 6
}
```

Solicitor application POST body:
```json
{
  "form_type": "solicitor_application",
  "firm_name": "...",
  "contact_name": "...",
  "email": "...",
  "phone": "...",
  "geographic_coverage": "...",
  "sra_regulated": true
}
```

---

## SEO Metadata

```ts
// app/page.tsx
export const metadata = {
  title: 'Settlement Agreement Calculator UK | Is Your Offer Fair? | SettlementCheck',
  description: 'Free settlement agreement calculator. Find out if your offer is fair in 60 seconds. Get matched with a vetted employment solicitor — your employer pays the fees.',
}

// app/results/page.tsx
export const metadata = {
  title: 'Your Settlement Estimate | SettlementCheck',
  description: 'Your personalised settlement agreement estimate. Get matched with a vetted employment solicitor — free, your employer pays.',
}

// app/for-solicitors/page.tsx
export const metadata = {
  title: 'Join Our Solicitor Panel | SettlementCheck',
  description: 'Receive pre-qualified settlement agreement leads from UK employees. SRA-regulated firms only.',
}
```

---

## next.config.js

```js
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: { unoptimized: true },
}
module.exports = nextConfig
```

Note: `output: 'export'` means `useSearchParams()` on the results page requires a `<Suspense>` wrapper (Next.js requirement for static export).

---

## Responsive Breakpoints

| Breakpoint | Behaviour |
|-----------|-----------|
| `≤ 900px` | Hero: single column (calc below text). Nav: burger menu. How-it-works: single column. Trust/FAQ grids: single column. |
| `≤ 720px` | Stats: 2-column. Footer: 2-column. CTA banner: single column. |
| `≤ 520px` | Calculator 2-col grid: single column. |

---

## Assets

No images. No icons library. All icons are inline SVG (simple geometric shapes only). The logo mark is a 22×22 SVG checkmark-in-rounded-square in coral. All placeholders in the prototype are structural (no image content needed for launch).

---

## Reference Files in This Package

| File | Purpose |
|------|---------|
| `SettlementCheck.html` | **Open this in a browser** — fully working hi-fi prototype |
| `calculator.js` | Calculator logic → copy to `lib/calculator.ts` |
| `styles.css` | Design tokens + base styles → extract to Tailwind config |
| `styles-page.css` | Page-specific layout styles → guide for Tailwind classes |
| `components/Navigation.jsx` | Navigation component reference |
| `components/Calculator.jsx` | Calculator widget reference |
| `components/Result.jsx` | Result card + lead form reference |
| `components/Sections.jsx` | All page sections reference |
